classdef TestBackgroundSubtractorMOG2
    %TestBackgroundSubtractorMOG2
    properties (Constant)
    end
    
    methods (Static)
        function test_1
            bs = cv.BackgroundSubtractorMOG2;
        end
    end
    
end

