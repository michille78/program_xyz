classdef TestBackgroundSubtractorKNN
    %TestBackgroundSubtractorKNN
    properties (Constant)
    end

    methods (Static)
        function test_1
            bs = cv.BackgroundSubtractorKNN;
        end
    end

end

