classdef TestBackgroundSubtractorMOG
    %TestBackgroundSubtractorMOG
    properties (Constant)
    end
    
    methods (Static)
        function test_1
            bs = cv.BackgroundSubtractorMOG;
        end
    end
    
end

