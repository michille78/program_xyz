classdef TestBackgroundSubtractorGMG
    %TestBackgroundSubtractorGMG
    properties (Constant)
    end

    methods (Static)
        function test_1
            bs = cv.BackgroundSubtractorGMG;
        end
    end

end

