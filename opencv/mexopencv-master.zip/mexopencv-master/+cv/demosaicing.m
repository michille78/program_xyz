%DEMOSAICING  Demosaicing algorithm
%
%    dst = cv.demosaicing(src, code)
%    dst = cv.demosaicing(..., 'OptionName', optionValue, ...)
%
% ## Input
% * __src__
% * __code__
%
% ## Output
% * __dst__
%
% ## Options
% * __Channels__
%
