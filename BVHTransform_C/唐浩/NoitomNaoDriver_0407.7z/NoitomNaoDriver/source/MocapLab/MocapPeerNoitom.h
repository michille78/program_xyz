#include "MocapPeer.h"

namespace MocapLab
{
	class MOCAPLAB_CORE MocapPeerNoitom : public MocapPeer
	{
	public:
		MocapPeerNoitom();
		virtual ~MocapPeerNoitom();

		boolean init( TaskManager& task_manager, boolean withDisplacement, boolean withReference, uint32 update_rate, int socket_type );
	};
}