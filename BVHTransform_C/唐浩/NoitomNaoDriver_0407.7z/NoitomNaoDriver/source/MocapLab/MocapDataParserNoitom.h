#include "MocapDataParser.h"

namespace MocapLab
{
	union NoitomDataVersion
	{
		uint32	version_mask;
		struct
		{
			uint8	build;
			uint8	revision;
			uint8	minor;
			uint8	major;
		};
	};

	#pragma pack( push )
	#pragma pack( 2 )
	struct NoitomDataHeader
	{
		enum : uint32
		{
			StartToken = 0XDDFF,
			EndToken = 0XEEFF,
			HeaderSize = 64,

			DataCountDisp = 59 * 6,
			DataCount = 3 + 60 * 3,
			DataCountRefDisp = 6 + DataCountDisp,
			DataCountRef = 6 + DataCount,

			DataSizeDisp = DataCountDisp * sizeof( float ),
			DataSize = DataCount * sizeof( float ),
			DataSizeRefDisp = DataCountRefDisp * sizeof( float ),
			DataSizeRef = DataCountRef * sizeof( float ),

			PacketSizeDisp = DataSizeDisp + HeaderSize,
			PacketSize = DataSize + HeaderSize,
			PacketSizeRefDisp = DataSizeRefDisp + HeaderSize,
			PacketSizeRef = DataSizeRef + HeaderSize
		};

		uint16						start_token;
		NoitomDataVersion			version;
		uint32						count;
		uint32						with_displacement;
		uint32						with_reference;
		uint32						avatar_index;
		uint8						avatar_name[32];
		uint32						reserved1;
		uint32						reserved2;
		uint16						end_token;
	};
	#pragma pack( pop )

	class MOCAPLAB_CORE MocapDataParserNoitom : public MocapDataParser
	{
		NoitomDataHeader			_header;
		float						_data[NoitomDataHeader::DataCountRefDisp];
		int							_count;
		static float				_scale;

	public:
		MocapDataParserNoitom();
		virtual ~MocapDataParserNoitom();

		virtual boolean validate( const uint8* data, Size size );
		virtual boolean parse( const void* data, Size size );
		virtual void applyToSkeleton( Skeleton* skeleton );

		inline virtual const float* data() const { return _data; }
		inline virtual int count() const { return _count; }

		inline const NoitomDataVersion& version() const { return _header.version; }
		inline boolean withDisplacement() const { return _header.with_displacement != 0; }
		inline boolean withReference() const { return _header.with_reference != 0; }
		inline uint32 avatarIndex() const { return _header.avatar_index; }
		const char* avatarName() const;
	};
}