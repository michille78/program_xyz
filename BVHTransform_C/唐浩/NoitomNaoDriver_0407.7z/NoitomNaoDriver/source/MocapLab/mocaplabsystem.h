#pragma once

#include "MocapLabCommon.h"
#include "Foundation/ThreadPool.h"
#include "Foundation/TaskManager.h"

namespace MocapLab
{
	class ThreadPool;
	class TaskManager;
	class DeviceManager;

	class MOCAPLAB_CORE MocapLabSystem
	{
		ThreadPool					_thread_pool;
		TaskManager					_task_manager;

		MocapLab::boolean			_done;
		MocapLab::boolean			_running;

		MocapLabSystem( const MocapLabSystem& other );
		MocapLabSystem& operator=( const MocapLabSystem& rhs );

		boolean _initThreadPool( uint32 thread_size );
		boolean _initTaskManager( uint32 runner_size );
		boolean _initDeviceManager();
		boolean _initPluginManager();

		void _releasePluginManager();
		void _releaseDeviceManager();
		void _releaseThreadPool();
		void _releaseTaskManager();

		void _registerBuiltInFactories();

	public:
		MocapLabSystem();
		~MocapLabSystem();

		MocapLab::boolean init( uint32 thread_size );
		void release();
		void update();
		void loop( uint32 update_rate );

		inline void shutdown() { _done = true; }
		inline void pause() { _running = false; }
		inline void resume() { _running = true; }

		// access
		inline MocapLab::boolean done() const { return _done; }
		inline MocapLab::boolean running() const { return _running; }
		inline ThreadPool& thread_pool() { return _thread_pool; }
		inline TaskManager& task_manager() { return _task_manager; }
	};
}