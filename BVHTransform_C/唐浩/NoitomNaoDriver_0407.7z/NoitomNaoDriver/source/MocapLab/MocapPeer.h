#pragma once

#include "MocapLabCommon.h"
#include "Foundation/Socket.h"
#include "Foundation/TaskManager.h"
#include "Foundation/Timer.h"

namespace MocapLab
{
	class MocapPeer;
	class MOCAPLAB_CORE MocapPeerUpateThread : public Task
	{
		MocapPeer*		_owner;
		Timer			_timer;
		uint32			_next_update;
		uint32			_update_rate;

	public:
		MocapPeerUpateThread( MocapPeer* owner, uint32 update_rate );
		virtual ~MocapPeerUpateThread();

		void update();
		void on_abort();
	};

	class MOCAPLAB_CORE MocapPeer
	{
	public:
		enum : int
		{
			Tcp,
			Udp
		};

	private:
		// thread
		TaskManager*			_task_manager;
		MocapPeerUpateThread*	_update_thread;

		// socket
		UdpSocket				_udp_socket;
		TcpClientSocket			_tcp_socket;

		// data
		uint8*					_data;
		MocapLab::Size			_buffer_size;
		MocapLab::Size			_received_size;

		// control
		boolean					_exit_flag;
		boolean					_connected;
		uint8					_socket_type;

	public:
		MocapPeer();
		virtual ~MocapPeer();

		boolean init( TaskManager& task_manager, MocapLab::Size buffer_size, uint32 update_rate, int socket_type );
		void release();

		boolean connect( const char* address, int port );
		void disconnect();
		void update();

		inline void* data() const { return _data; }
		inline MocapLab::Size size() const { return _received_size; }
		inline boolean running() const { return !_exit_flag; }
		inline boolean connected() const { return _connected; }
		inline int socketType() const { return _socket_type; }
	};
}