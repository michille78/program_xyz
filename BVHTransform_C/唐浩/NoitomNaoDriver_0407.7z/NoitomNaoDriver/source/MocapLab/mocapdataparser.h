#pragma once

#include "MocapLabCommon.h"

namespace MocapLab
{
	class Skeleton;
	class MOCAPLAB_CORE MocapDataParser
	{
	public:
		MocapDataParser();
		virtual ~MocapDataParser();

		virtual boolean validate( const uint8* data, MocapLab::Size size ) = 0;
		virtual boolean parse( const void* data, MocapLab::Size size ) = 0;
		virtual void applyToSkeleton( Skeleton* skeleton ) = 0;

		// access
		virtual const float* data() const = 0;
		virtual int count() const = 0;
	};
}