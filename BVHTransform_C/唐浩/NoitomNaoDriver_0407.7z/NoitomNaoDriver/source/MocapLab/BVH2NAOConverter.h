#pragma once

#include "MocapLabCommon.h"
#include "BVH_NAO_Interpreter/BVHTransform_c.h"

namespace MocapLab
{
	class MOCAPLAB_CORE BVH2NAOConverter
	{
	public:
		static void Convert( const float* in_data, double* out_data );
	};
}