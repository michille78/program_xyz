#pragma once

// foundation
#include "Foundation/FoundationCommon.h"

#ifdef MOCAPLAB_BUILD
#define MOCAPLAB_CORE __declspec( dllexport )
#else
#define MOCAPLAB_CORE __declspec( dllimport )
#endif

namespace MocapLab
{
}