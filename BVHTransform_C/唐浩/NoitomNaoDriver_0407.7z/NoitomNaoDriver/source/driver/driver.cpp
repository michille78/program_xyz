﻿#include <cassert>
#include <cstdlib>
#include <cstdio>

#include "Foundation/Timer.h"
#include "MocapLab/MocapLabSystem.h"
#include "MocapLab/MocapPeerNoitom.h"
#include "MocapLab/MocapDataParserNoitom.h"
#include "MocapLab/BVH2NAOConverter.h"
#include "Foundation/Socket.h"
#include "Foundation/Network.h"

using namespace MocapLab;

void process(const float* data, TcpClientSocket& sender, FILE* logfile)
{
	// convert
	double buffer_out[25];
	memset(buffer_out, 0, sizeof(buffer_out));
	BVH2NAOConverter::Convert(data, buffer_out);

	// apply packet format
	MocapLab::Size packet_size = 25 * sizeof(float) + sizeof('D') + sizeof(uint8);
	uint8* packet_data = new uint8[packet_size];
	assert(packet_data);
	float* float_out = reinterpret_cast<float*>(packet_data);
	for (int i = 0; i < 25; ++i)
	{
		float_out[i] = static_cast<float>(buffer_out[i]);
	}

	// mark 
	packet_data[packet_size - 2] = 'D';
	packet_data[packet_size - 1] = 0;

	// send packet
	if (sender.connected())
	{
		sender.send(packet_data, packet_size);
	}

	// stream to console and file
	for (int i = 0; i < 25; ++i)
	{
		printf("nao[%d] = %f, ", i, buffer_out[i]);
		if (logfile)
		{
			char line[32];
			sprintf(line, "%f ", buffer_out[i]);
			fwrite(line, strlen(line), 1, logfile);
		}
	}
	printf("\n");
	if (logfile)
	{
		fputs("\n", logfile);
	}

	// clean up
	delete[] packet_data;
	packet_data = 0;
}

int main(int argc, char** argv)
{
	MocapLabSystem sys;
	MocapPeerNoitom peer;
	TcpClientSocket sender;

	string server_address = "127.0.0.1";
	int server_port = 7001;
	string target_address = "127.0.0.1";
	int target_port = 6000;
	string log_path;
	uint32 sample_rate = 100;

	// load config
	FILE* file = 0;
	errno_t err = fopen_s(&file, "Config.txt", "r");
	if (file)
	{
		while (!feof(file))
		{
			char line[1024];
			memset(line, 0, sizeof(line));
			fgets(line, 1024, file);

			char* token = strtok(line, "=\n");
			if (token)
			{
				if (strcmp(token, "ServerAddress") == 0)
				{
					token = strtok(0, "=\n");
					if (token)
					{
						server_address = token;
					}
				}
				else if (strcmp(token, "ServerPort") == 0)
				{
					token = strtok(0, "=\n");
					if (token)
					{
						server_port = atoi(token);
					}
				}
				else if (strcmp(token, "TargetAddress") == 0)
				{
					token = strtok(0, "=\n");
					if (token)
					{
						target_address = token;
					}
				}
				else if (strcmp(token, "TargetPort") == 0)
				{
					token = strtok(0, "=\n");
					if (token)
					{
						target_port = atoi(token);
					}
				}
				else if (strcmp(token, "LogPath") == 0)
				{
					token = strtok(0, "=\n");
					if (token)
					{
						log_path = token;
					}
				}
			}
		}

		fclose(file);
		file = 0;
	}

	// prepare log file
	FILE* logfile = 0;
	if (!log_path.empty())
	{
		errno_t err = fopen_s(&logfile, log_path.c_str(), "w");
	}

	Network::init();

	// prepare sender
	if (!sender.init(target_address.c_str(), target_port) || !sender.connect())
	{
		printf("connect to target %s:%d failed\n", target_address.c_str(), target_port);
	}
	else
	{
		printf("connect to target %s:%d\n", target_address.c_str(), target_port);
	}

	printf("press any key to start...");
	system("pause");

	//process;
	MocapDataParserNoitom parser;
	if (sys.init(3))
	{
		if (peer.init(sys.task_manager(), true, false, 50, MocapPeer::Tcp))
		{
			if (peer.connect(server_address.c_str(), server_port))
			{
				Timer timer;
				int count = 0;
				while (!sys.done())
				{
					if (timer.elapsedMS() >= sample_rate)
					{
						if (parser.parse(peer.data(), peer.size()))
						{
							printf("frame count: %u\n", count);
							printf("time: %u\n", timer.elapsedMS());

							if (parser.withDisplacement())
							{
								process(parser.data(), sender, logfile);
							}

							++count;
						}
						else
						{
							printf("parse error.\n");
						}

						sys.update();

						timer.reset();
					}
				}
			}
			else
			{
				printf("connect to remote failed\n");
			}
		}
		else
		{
			printf("init peer failed\n");
		}
	}
	else
	{
		printf("init system failed\n");
	}

	peer.release();
	sys.release();

	sender.release();

	Network::release();

	if (logfile)
	{
		fclose(logfile);
		logfile = 0;
	}

	system("pause");
	return 0;
}