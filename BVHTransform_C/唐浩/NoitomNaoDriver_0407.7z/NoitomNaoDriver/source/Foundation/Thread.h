#pragma once

#include "FoundationCommon.h"

namespace MocapLab
{
	class MOCAPLAB_FOUNDATION_CORE SimpleLock
	{
		MOCAPLAB_LOCK		_lock;

		SimpleLock( const SimpleLock& other );
		SimpleLock& operator=( const SimpleLock& rhs );

	public:
		SimpleLock() { initLock( &_lock ); }
		virtual ~SimpleLock() { closeLock( &_lock ); }

		inline void acquire() { acquireLock( &_lock ); }
		inline boolean tryAcquire() { return tryAcquireLock( &_lock ); }
		inline void release() { releaseLock( &_lock ); }
	};

	class MOCAPLAB_FOUNDATION_CORE SimpleEvent
	{
		MOCAPLAB_EVENT		_event;

		SimpleEvent( const SimpleEvent& other );
		SimpleEvent& operator=( const SimpleEvent& rhs );

	public:
		SimpleEvent() : _event( 0 ) {}
		~SimpleEvent() {}

		boolean init( boolean manual_reset, boolean initial_state ) { _event = initEvent( manual_reset, initial_state ); return _event != 0; }
		void release() { closeEvent( _event ); }
		void set() { setEvent( _event ); }
		void reset() { resetEvent( _event ); }
		void wait( uint32 time_ms ) { waitEvent( _event, time_ms ); }
	};

	class MOCAPLAB_FOUNDATION_CORE ScopedLock
	{
		SimpleLock*			_lock;

		ScopedLock( const ScopedLock& other );
		ScopedLock& operator=( const ScopedLock& rhs );

	public:
		ScopedLock( SimpleLock& lock ) : _lock( &lock ) { _lock->acquire(); }
		~ScopedLock() { _lock->release(); }
	};

	class MOCAPLAB_FOUNDATION_CORE ReadWriteLock
	{
		SimpleLock			_counter_lock;
		SimpleLock			_write_lock;
		volatile uint32		_counter;

		ReadWriteLock( const ReadWriteLock& other );
		ReadWriteLock& operator=( const ReadWriteLock& rhs );

	public:
		ReadWriteLock();
		~ReadWriteLock();

		void lockRead();
		void unlockRead();
		void lockWrite();
		void unlockWrite();
	};

	class MOCAPLAB_FOUNDATION_CORE SimpleThread
	{
	public:
		typedef MOCAPLAB_THREAD_ENTRY ThreadFunc;

		enum : uint32
		{
			WAIT_TIME_INFINITE = MOCAPLAB_THREAD_INFINITE
		};

	private:
		MOCAPLAB_THREAD_ID				_id;
		MOCAPLAB_THREAD_HANDLE			_handle;

		SimpleThread( const SimpleThread& other );
		SimpleThread operator=( const SimpleThread& rhs );

	public:
		SimpleThread();
		~SimpleThread();

		boolean init( ThreadFunc func, void* arg );
		void release();

		void start();
		void pause();
		void wait( uint32 time_ms = WAIT_TIME_INFINITE );

		inline MOCAPLAB_THREAD_ID id() const { return _id; }
		inline MOCAPLAB_THREAD_HANDLE handle() const { return _handle; }
	};
}