#pragma once

#include "FoundationCommon.h"

namespace MocapLab
{
	class MOCAPLAB_FOUNDATION_CORE Network
	{
	public:
		Network();
		virtual ~Network();

		static boolean init();
		static void release();
	};
}