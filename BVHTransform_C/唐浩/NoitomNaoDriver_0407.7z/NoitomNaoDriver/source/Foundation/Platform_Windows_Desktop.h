#pragma once

#ifdef _WIN32

// platform symbol
#define MOCAPLAB_PLATFORM_WINDOWS_DESKTOP

// compiler
#define MOCAPLAB_BUILD_COMPILER_MSC
#define MOCAPLAB_BUILD_COMPILER_VERSION _MSC_FULL_VER
#define MOCAPLAB_BUILD_COMPILER_BUILD _MSC_BUILD

#if defined _M_AMD64
#define MOCAPLAB_BUILD_AMD64
#elif defined _M_IX86
#define MOCAPLAB_BUILD_IX86
#elif defined _M_IA64
#define MOCAPLAB_BUILD_IA64
#elif defined _M_x64
#define MOCAPLAB_BUILD_X64
#endif

#if defined _WIN64
#define MOCAPLAB_BUILD_64BIT
#else
#define MOCAPLAB_BUILD_32BIT
#endif

#ifdef _DEBUG
#define MOCAPLAB_BUILD_DEBUG
#endif

#pragma warning( disable: 4251 )
#pragma warning( disable: 4996 )

// includes
#include <WinSock2.h>
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <process.h>

#include <cassert>
#include <unordered_set>
using std::unordered_set;
#include <deque>
using std::deque;
#include <vector>
using std::vector;
#include <string>
using std::string;
#include <map>
using std::map;
#include <unordered_map>
using std::unordered_map;

namespace MocapLab
{
	// language
#define MOCAPLAB_FORCE_INLINE __forceinline

	typedef bool boolean;
	typedef wchar_t wchar;
	typedef char int8;
	typedef short int16;
	typedef int int32;
	typedef __int64 int64;
	typedef unsigned char uint8;
	typedef unsigned short uint16;
	typedef unsigned int uint32;
	typedef unsigned __int64 uint64;

#if defined MOCAPLAB_BUILD_32BIT
	typedef unsigned int uintptr;
	typedef unsigned int Size;
#else
	typedef unsigned __int64 uintptr;
	typedef unsigned __int64 Size;
#endif

#define MOCAPLAB_FLT_MIN													FLT_MIN
#define MOCAPLAB_FLT_MAX													FLT_MAX
#define MOCAPLAB_DBL_MIN													DBL_MIN
#define MOCAPLAB_DBL_MAX													DBL_MAX

	// memory
	inline void* alloc( Size s ) { return ::malloc( s ); }
	inline void* realloc( void* p, Size s ) { return ::realloc( p, s ); }
	inline void free( void* p ) { return ::free( p ); }

	// plugin
#define MOCAPLAB_PROCESS_INSTANCE											HINSTANCE
#define MOCAPLAB_PLUGIN_HANDLE												HMODULE
#define MOCAPLAB_PLUGIN_EXPORT												__declspec( dllexport )
#define MOCAPLAB_PLUGIN_IMPORT												__declspec( dllimport )
#define MOCAPLAB_PLUGIN_SYMBOL_ADDRESS										FARPROC

	inline MOCAPLAB_PLUGIN_HANDLE loadPlugin( const char* path ) { return ::LoadLibraryA( path ); }
	inline void unloadPlugin( MOCAPLAB_PLUGIN_HANDLE plugin ) { ::FreeLibrary( plugin ); }
	inline MOCAPLAB_PLUGIN_SYMBOL_ADDRESS getPluginSymbol( MOCAPLAB_PLUGIN_HANDLE plugin, const char* name ) { return ::GetProcAddress( plugin, name ); }

	// lock & event
#define MOCAPLAB_LOCK														CRITICAL_SECTION
#define MOCAPLAB_EVENT														HANDLE
#define MOCAPLAB_WAIT_TIME_INFINITE											INFINITE

	inline void initLock( MOCAPLAB_LOCK* lock ) { return ::InitializeCriticalSection( lock ); }
	inline void acquireLock( MOCAPLAB_LOCK* lock ) { ::EnterCriticalSection( lock ); }
	inline boolean tryAcquireLock( MOCAPLAB_LOCK* lock ) { return ::TryEnterCriticalSection( lock ) == TRUE; }
	inline void releaseLock( MOCAPLAB_LOCK* lock ) { ::LeaveCriticalSection( lock ); }
	inline void closeLock( MOCAPLAB_LOCK* lock ) { ::DeleteCriticalSection( lock ); }
	inline MOCAPLAB_EVENT initEvent( boolean manual_reset, boolean initial_state ) { return CreateEvent( 0, manual_reset, initial_state, 0 ); }
	inline void setEvent( MOCAPLAB_EVENT e ) { ::SetEvent( e ); }
	inline void resetEvent( MOCAPLAB_EVENT e ) { ::ResetEvent( e ); }
	inline void waitEvent( MOCAPLAB_EVENT e, uint32 time ) { ::WaitForSingleObject( e, time ); }
	inline void waitEvents( MOCAPLAB_EVENT* e, uint32 num_events, boolean wait_all, uint32 time ) { ::WaitForMultipleObjects( num_events, e, wait_all, time ); }
	inline void closeEvent( MOCAPLAB_EVENT e ) { ::CloseHandle( e ); e = 0; }

	// atom operations
	inline boolean atomCAS16( volatile int16* x, int16 v1, int16 v0 ) { return InterlockedCompareExchange16( x, v1, v0 ) == v0; }
	inline boolean atomCAS32( volatile uint32* x, uint32 v1, uint32 v0 ) { return InterlockedCompareExchange( x, v1, v0 ) == v0; }
	inline boolean atomCAS64( volatile int64* x, int64 v1, int64 v0 ) { return InterlockedCompareExchange64( x, v1, v0 ) == v0; }
	inline void atomIncrement16( volatile int16* x ) { InterlockedIncrement16( x ); }
	inline void atomIncremenet32( volatile uint32* x ) { InterlockedIncrement( x ); }
	inline void atomIncremenet64( volatile int64* x ) { InterlockedIncrement64( x ); }
	inline void atomDecremenet16( volatile int16* x ) { InterlockedDecrement16( x ); }
	inline void atomDecremenet32( volatile uint32* x ) { InterlockedDecrement( x ); }
	inline void atomDecremenet64( volatile int64* x ) { InterlockedDecrement64( x ); }

	// thread
typedef uint32( __stdcall * _ThreadFunc )( void* );
#define MOCAPLAB_THREAD_ENTRY												_ThreadFunc
#define MOCAPLAB_THREAD_HANDLE												HANDLE
#define MOCAPLAB_THREAD_ID													uint32
#define MOCAPLAB_THREAD_YIELD												SwitchToThread
#define MOCAPLAB_THREAD_INFINITE											INFINITE

	inline MOCAPLAB_THREAD_HANDLE initThread( MOCAPLAB_THREAD_ENTRY entry, void* args, MOCAPLAB_THREAD_ID* thread_id ) { return (MOCAPLAB_THREAD_HANDLE)::_beginthreadex( 0, 0, entry, args, CREATE_SUSPENDED, thread_id ); }
	inline void resumeThread( MOCAPLAB_THREAD_HANDLE t ) { ::ResumeThread( t ); }
	inline void suspendThread( MOCAPLAB_THREAD_HANDLE t ) { ::SuspendThread( t ); }
	inline MOCAPLAB_THREAD_ID currentThreadID() { return ::GetCurrentThreadId(); }
	inline void waitThread( MOCAPLAB_THREAD_HANDLE t, uint32 time ) { ::WaitForSingleObject( t, time ); }
	inline void waitThreads( MOCAPLAB_THREAD_HANDLE* t, uint32 num_threads, boolean wait_all, uint32 time ) { ::WaitForMultipleObjects( num_threads, t, wait_all, time ); }
	inline void closeThread( MOCAPLAB_THREAD_HANDLE t ) { ::CloseHandle( t ); }
	inline void sleep( uint32 time ) { ::Sleep( time ); }
	inline void yield() { ::SwitchToThread(); }

	// network
	inline void networkStartup() { WSADATA data; WSAStartup( MAKEWORD( 2, 2 ), &data ); }
	inline void networkShutdown() { WSACleanup(); }

	struct Guid
	{
		uint32		data1;
		uint16		data2;
		uint16		data3;
		uint16		data4;
		uint64		data5;
	};

	inline Guid generateGuid()
	{
		GUID native;
		CoCreateGuid( &native );
		Guid ret;
		ret.data1 = native.Data1;
		ret.data2 = native.Data2;
		ret.data3 = native.Data3;
		ret.data4 = *reinterpret_cast<uint16*>( &native.Data4 );
		ret.data5 = *reinterpret_cast<uint64*>( &native.Data4[2] );
		return ret;
	}
}
#endif