#pragma once

#include "FoundationCommon.h"

namespace MocapLab
{
	class MOCAPLAB_FOUNDATION_CORE NetAddress
	{
		uint32			_address;
		int				_port;

	public:
		NetAddress();
		NetAddress( const char* address, int port );
		NetAddress( const NetAddress& other );
		virtual ~NetAddress();

		NetAddress& operator=( const NetAddress& rhs );

		uint32 hashValue() const;
		static uint32 hashValue( const char* address, int port );

		inline void setAddressHostFormat( const char* address ) { _address = inet_addr( address ); }
		inline void setPortHostFormat( int port ) { _port = htons( (uint16)port ); }
		inline const char* addressHostFormat() const { return inet_ntoa( *(in_addr*)( &_address ) ); }
		inline uint16 portHostFormat() const { return ntohs( (uint16)_port ); }
		inline uint32 address() const { return _address; }
		inline uint32& address() { return _address; }
		inline int port() const { return _port; }
		inline int& port() { return _port; }
	};
}