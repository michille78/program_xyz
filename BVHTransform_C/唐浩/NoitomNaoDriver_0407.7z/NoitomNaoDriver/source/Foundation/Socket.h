#pragma once

#include "FoundationCommon.h"
#include "NetAddress.h"

namespace MocapLab
{
	enum : uint8
	{
		SOCKET_TYPE_UNKNOWN = 0,
		SOCKET_TYPE_STREAM = 1,
		SOCKET_TYPE_DGRAM = 2,
		SOCKET_TYPE_UDT_STREAM = 3,
		SOCKET_TYPE_UDT_DGRAM = 4
	};

	enum : uint8
	{
		SOCKET_RETURN_OK,
		SOCKET_RETURN_NOTHING,
		SOCKET_RETURN_BLOCK,
		SOCKET_RETURN_REMOTE_CLOSED,
		SOCKET_RETURN_LOST_CONNECTION,
		SOCKET_RETURN_ERROR_UNKNOWN,
	};

	typedef struct
	{
		int				socket;
		uint8			socket_type;
		NetAddress		address;

	}SocketData;

	// UDP socket
	class MOCAPLAB_FOUNDATION_CORE UdpSocket
	{
		SocketData		_socket_data;
		boolean			_block;

	public:
		UdpSocket();
		virtual ~UdpSocket();

		boolean init( const char* address, uint16 port, boolean block = true );
		void release();

		uint8 send( const NetAddress& remote_address, uint8* buffer, MocapLab::Size size, MocapLab::Size* sent_size = 0 );
		uint8 send( const char* address, uint16 port, uint8* buffer, MocapLab::Size size, MocapLab::Size* sent_size = 0 ) { return send( NetAddress( address, port ), buffer, size, sent_size ); }
		uint8 recv( uint8* buffer, MocapLab::Size size, MocapLab::Size* received_size, NetAddress* remote_address = 0 );

		const NetAddress& address() const { return _socket_data.address; }
		inline boolean block() const { return _block; }
	};

	// TCP sockets
	class MOCAPLAB_FOUNDATION_CORE TcpServerSocket
	{
		SocketData		_socket_data;
		boolean			_block;

	public:
		TcpServerSocket();
		virtual ~TcpServerSocket();

		boolean init( const char* address, uint16 port, boolean block = true );
		void release();

		void listen();
		boolean accept( SocketData& remote_socket );

		const NetAddress& address() const { return _socket_data.address; }
		inline boolean block() const { return _block; }
	};

	class MOCAPLAB_FOUNDATION_CORE TcpClientSocket
	{
		SocketData		_remote_socket_data;
		boolean			_block;
		boolean			_connected;

	public:
		TcpClientSocket();
		virtual ~TcpClientSocket();

		boolean init( const char* address, uint16 port, boolean block = true );
		void release();

		boolean connect();
		uint8 send( uint8* buffer, MocapLab::Size size, MocapLab::Size* sent_size = 0 );
		uint8 recv( uint8* buffer, MocapLab::Size size, MocapLab::Size* received_size = 0 );

		const NetAddress& remote_address() const { return _remote_socket_data.address; }
		inline boolean block() const { return _block; }
		inline boolean connected() const { return _connected; }
	};

	class MOCAPLAB_FOUNDATION_CORE TcpSessionSocket
	{
		SocketData		_socket_data;
		boolean			_block;

	public:
		TcpSessionSocket();
		virtual ~TcpSessionSocket();

		boolean init( const SocketData& socket_data, boolean block = true );
		void release();

		uint8 send( uint8* buffer, MocapLab::Size size, MocapLab::Size* sent_size = 0 );
		uint8 recv( uint8* buffer, MocapLab::Size size, MocapLab::Size* received_size = 0 );

		const NetAddress& address() const { return _socket_data.address; }
		inline boolean block() const { return _block; }
	};
}