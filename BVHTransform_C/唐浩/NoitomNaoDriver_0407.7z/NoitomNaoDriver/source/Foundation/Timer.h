#pragma once

#include "FoundationCommon.h"

namespace MocapLab
{
#ifdef MOCAPLAB_PLATFORM_WINDOWS_DESKTOP

	class MOCAPLAB_FOUNDATION_CORE Timer
	{
		int64			_start;
		static int64	_frequency;

	public:
		Timer();
		~Timer();

		static int64 now();
		inline void reset();

		static uint64 timeUS();
		static inline uint32 timeMS() { return static_cast<uint32>( timeUS() / 1000ULL ); }

		uint64 elapsedUS();
		inline uint32 elapsedMS() { return static_cast<uint32>( elapsedUS() / 1000ULL ); }
	};

#endif
}