#pragma once

#include "FoundationCommon.h"
#include "Thread.h"
#include "AsyncQueue.h"

namespace MocapLab
{
	class MOCAPLAB_FOUNDATION_CORE ThreadRequest
	{
		friend class ThreadPool;
		boolean				_started;
		boolean				_finished;
		volatile boolean	_abort_flag;

	public:
		ThreadRequest()
			:_started( false )
			,_finished( false )
			,_abort_flag( false )
		{}
		virtual ~ThreadRequest() {}

		virtual uint32 run() = 0;
		void abort() { _abort_flag = true; }

		inline boolean started() const { return _started; }
		inline boolean finished() const { return _finished; }
		inline boolean aborted() const { return _abort_flag; }
	};

	class MOCAPLAB_FOUNDATION_CORE ThreadPool
	{
		AsyncQueue<ThreadRequest*>				_pending_requests;
		AsyncQueue<ThreadRequest*>				_running_requests;
		AsyncQueue<SimpleThread*>				_threads;
		vector<MOCAPLAB_THREAD_HANDLE>			_thread_handles;
		volatile boolean						_flush_flag;
		volatile boolean						_destroy_flag;
		MOCAPLAB_EVENT							_new_task_event;
		MOCAPLAB_EVENT							_destroy_event;

		static uint32 __stdcall ThreadPool::work( void* arg );
		boolean _initThreads( uint32 thread_count, uint32 num_max_requests );
		void _releaseThreads();
		boolean _processRequests();

	public:
		ThreadPool();
		virtual ~ThreadPool();

		boolean init( uint32 thread_count, uint32 num_max_requests );
		void release();
		void update();

		boolean assign( ThreadRequest* request );
		void flush();

		uint32 thread_count() const { return _threads.size(); }
		uint32 pending_request_count() const { return _pending_requests.size(); }
		uint32 running_request_count() const { return _running_requests.size(); }
	};
}