#pragma once

#include "FoundationCommon.h"
#include "ThreadPool.h"

namespace MocapLab
{
	class MOCAPLAB_FOUNDATION_CORE Task
	{
		boolean				_started;			// task start flag, may not running in a thread
		boolean				_end;				// task end flag, finished or aborted
		boolean				_running;			// task running, task running in a thread
		boolean				_hold_thread;		// task will not release its running thread until end

	public:
		Task();
		virtual ~Task();

		virtual void update() = 0;
		virtual void on_abort() = 0;

		inline void start() { _started = true; }
		inline void stop() { _started = false; }
		inline void end() { _end = true; }
		inline void set_running( boolean running ) { _running = running; }
		inline void hold_thread( boolean hold ) { _hold_thread = hold; }
		inline boolean started() const { return _started; }
		inline boolean stopped() const { return !_started; }
		inline boolean running() const { return _running; }
		inline boolean ended() const { return _end; }
		inline boolean thread_holded() const { return _hold_thread; }
	};

	class TaskManager;

	class MOCAPLAB_FOUNDATION_CORE TaskRunner : public ThreadRequest
	{
		Task*					_task;
		TaskManager*			_owner;
		boolean					_task_abort_flag;

	public:
		TaskRunner( TaskManager* owner );
		virtual ~TaskRunner();

		virtual uint32 run();

		inline void set_task( Task* task ) { _task = task; }
		inline Task* task() { return _task; }
		inline void abort_task( boolean abort ) { _task_abort_flag = abort; }
	};

	class MOCAPLAB_FOUNDATION_CORE TaskManager : public ThreadRequest
	{
		friend class TaskRunner;
		ThreadPool*					_thread_pool;
		vector<TaskRunner*>			_runners;
		AsyncQueue<TaskRunner*>		_idle_runners;
		AsyncQueue<Task*>			_tasks;
		boolean						_flush_flag;
		boolean						_halt_flag;
		boolean						_destroy_flag;
		
		void _assignTasksToRunners();
		void _releaseRunnerFromTask( TaskRunner* runner );

	public:
		TaskManager();
		virtual ~TaskManager();

		boolean init( ThreadPool& thread_pool, uint32 num_runners, uint32 task_capacity );
		void release();

		boolean assign( Task* task );
		void update();
		virtual uint32 run() { update(); return 0; }
		virtual void on_task_end( Task* task );

		// flush will prevent new task assignment
		void flush();

		// halt will prevent new task assignment and new task running
		inline void halt() { _halt_flag = true; }
		inline void proceed() { _halt_flag = false; }
	};
}