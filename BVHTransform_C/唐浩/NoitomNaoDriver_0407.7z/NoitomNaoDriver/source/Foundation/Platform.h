#pragma once

#ifdef _WIN32
#include "Platform_Windows_Desktop.h"
#endif

namespace MocapLab
{
}