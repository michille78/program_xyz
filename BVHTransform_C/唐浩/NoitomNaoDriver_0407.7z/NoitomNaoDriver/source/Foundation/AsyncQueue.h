#pragma once

#include "FoundationCommon.h"

namespace MocapLab
{
	template<typename T>
	class MOCAPLAB_FOUNDATION_CORE AsyncQueue
	{
		MocapLab::Size					_push_index;
		MocapLab::Size					_pop_index;
		MocapLab::Size					_max_pop_index;
		MocapLab::Size					_capacity;
		volatile MocapLab::Size			_size;
		vector<T>						_data;

	public:
		AsyncQueue()
			:_push_index( 0 )
			,_pop_index( 0 )
			,_max_pop_index( 0 )
			,_capacity( 0 )
			,_size( 0 )
		{
		}

		AsyncQueue( MocapLab::Size capacity )
			:_push_index( 0 )
			,_pop_index( 0 )
			,_max_pop_index( 0 )
			,_capacity( 0 )
			,_size( 0 )
		{
			reserve( capacity );
		}

		~AsyncQueue()
		{
		}

		void reserve( MocapLab::Size capacity )
		{
			_data.resize( capacity + 1 );
			_capacity = capacity + 1;
		}

		inline MocapLab::Size size() const { return _size; }
		inline boolean any() const { return _size > 0; }
		inline boolean empty() const { return _size == 0; }

		boolean push( const T& item )
		{
			MocapLab::Size pop_index = 0;
			MocapLab::Size push_index = 0;

			// try next space
			do
			{
				push_index = _push_index;
				pop_index = _pop_index;
				if( ( push_index + 1 ) % _capacity == pop_index % _capacity )
				{
					// full
					return false;
				}

			}while( !atomCAS32( &_push_index, ( push_index + 1 ), push_index ) );

			// commit
			_data[ push_index % _capacity ] = item;

			// set max_pop counter
			while( !atomCAS32( &_max_pop_index, ( push_index + 1 ), push_index ) )
			{
				MOCAPLAB_THREAD_YIELD();
			}

			// upate size
			atomIncremenet32( &_size );

			return true;
		}

		boolean pop( T& item )
		{
			MocapLab::Size max_pop_index;
			MocapLab::Size pop_index;

			do
			{
				// pin point
				pop_index = _pop_index;
				max_pop_index = _max_pop_index;

				if( pop_index % _capacity == max_pop_index % _capacity )
				{
					// empty or producer has the space but not commit
					return false;
				}

				// fetch
				item = _data[ pop_index % _capacity ];

				// set pop counter
				if( atomCAS32( &_pop_index, ( pop_index + 1 ), pop_index ) )
				{
					atomDecremenet32( &_size );
					return true;
				}

			}while( 1 );

			// SHOULD NOT REACH HERE
			assert( 0 );
			return false;
		}
	};
}