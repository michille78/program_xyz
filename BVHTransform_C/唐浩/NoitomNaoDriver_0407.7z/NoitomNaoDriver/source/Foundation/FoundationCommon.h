#pragma once

#include "Platform.h"

#ifdef MOCAPLAB_FOUNDATION_BUILD
#define MOCAPLAB_FOUNDATION_CORE __declspec( dllexport )
#else
#define MOCAPLAB_FOUNDATION_CORE __declspec( dllimport )
#endif

namespace MocapLab
{
	template<uint8 ch0, uint8 ch1, uint8 ch2, uint8 ch3>
	struct MakeFourCC
	{
		enum : uint32
		{
			value = (ch0 << 0) + (ch1 << 8) + (ch2 << 16) + (ch3 << 24)
		};
	};
}