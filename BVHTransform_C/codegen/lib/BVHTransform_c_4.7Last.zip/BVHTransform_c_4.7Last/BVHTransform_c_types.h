// 
// File: BVHTransform_c_types.h 
//  
// MATLAB Coder version            : 2.6 
// C/C++ source code generated on  : 07-Apr-2015 20:00:35 
//

#ifndef __BVHTRANSFORM_C_TYPES_H__
#define __BVHTRANSFORM_C_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
// 
// File trailer for BVHTransform_c_types.h 
//  
// [EOF] 
//
