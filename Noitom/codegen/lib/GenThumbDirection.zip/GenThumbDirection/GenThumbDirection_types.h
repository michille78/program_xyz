/* 
 * File: GenThumbDirection_types.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 27-May-2015 16:37:00 
 */

#ifndef __GENTHUMBDIRECTION_TYPES_H__
#define __GENTHUMBDIRECTION_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* 
 * File trailer for GenThumbDirection_types.h 
 *  
 * [EOF] 
 */
