/* 
 * File: _coder_GenThumbDirection_info.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 27-May-2015 16:37:00 
 */

#ifndef ___CODER_GENTHUMBDIRECTION_INFO_H__
#define ___CODER_GENTHUMBDIRECTION_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_GenThumbDirection_info.h 
 *  
 * [EOF] 
 */
